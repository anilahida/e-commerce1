<?php
define('DB_HOST', 'localhost');
define('DB_NAME', 'ecommerce_db');
define('DB_USER', 'root');
define('DB_PASS', '');
define('BASE_URL', '/e-commerce1/e-commerce1');
define('SITE_NAME', 'E-commerce Skincare');
